const express = require('express');
const router = express.Router();
const { imageValidator } = require('../middlewares/validator');
const { upload } = require('../utils/utilities');
const { resourceUpload, signup, adminApprove, getAllRequest, getOneRequest } = require('../controllers/adminController');
const { authorize } = require('../middlewares/auth');


router.post('/api/adminsignup', signup)
router.post('/api/uploadresource', upload.single("file"), imageValidator, resourceUpload)
router.get('/api/approve/:reqId', authorize, adminApprove),
    router.get('/api/admin/requests/:reqId', authorize, getOneRequest)
router.get('/api/admin/requests', authorize, getAllRequest)


module.exports = router;